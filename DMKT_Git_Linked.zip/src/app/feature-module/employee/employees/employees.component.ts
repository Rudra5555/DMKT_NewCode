import { Component, NgZone } from '@angular/core';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.scss']
})


export class EmployeesComponent {
  

  constructor(private ngZone: NgZone) {
  }





}
