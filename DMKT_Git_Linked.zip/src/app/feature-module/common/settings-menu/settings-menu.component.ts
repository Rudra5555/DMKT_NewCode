import { Component } from '@angular/core';
import { SideBarService } from 'src/app/core/core.index';

@Component({
  selector: 'app-settings-menu',
  templateUrl: './settings-menu.component.html',
  styleUrls: ['./settings-menu.component.scss'],
})
export class SettingsMenuComponent {
  
}
