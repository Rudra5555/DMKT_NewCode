import { Component } from '@angular/core';

@Component({
  selector: 'app-tokbox',
  templateUrl: './tokbox.component.html',
  styleUrls: ['./tokbox.component.scss']
})
export class TokboxComponent {



  

}
